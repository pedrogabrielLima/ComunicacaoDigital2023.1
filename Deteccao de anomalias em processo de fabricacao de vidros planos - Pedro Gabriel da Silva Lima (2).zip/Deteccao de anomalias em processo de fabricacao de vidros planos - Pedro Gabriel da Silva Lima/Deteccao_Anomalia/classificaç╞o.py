import os
import math
import pandas
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import train_test_split

agrupamento_dir = "agrupamento"
kmeans_dir = os.path.join(agrupamento_dir, "kmeans")
dbscan_dir = os.path.join(agrupamento_dir, "dbscan")

csvs = [fn for fn in os.listdir(kmeans_dir) if fn.endswith(".csv")]
for csv in csvs:
    df = pandas.read_csv(os.path.join(kmeans_dir, csv))
    x_df = df.drop("cluster", axis=1)
    y_df = df["cluster"]
    x_train_df, x_test_df, y_train_df, y_test_df = train_test_split(x_df, y_df, test_size=0.3)
    knn_model = KNeighborsRegressor(n_neighbors=3)
    knn_model.fit(x_train_df, y_train_df)
    train_preds = knn_model.predict(x_train_df)
    mse = mean_squared_error(y_train_df.values, train_preds)
    rmse = math.sqrt(mse)
    print(f"[KMeans {csv}] Erro medio quadratico treino: {rmse}")
    test_preds = knn_model.predict(x_test_df)
    mse = mean_squared_error(y_test_df, test_preds)
    rmse = math.sqrt(mse)
    print(f"[KMeans {csv}] Erro medio quadratico teste: {rmse}")

    columns = [c for c in df.columns if c not in ['Unnamed: 0', 'data_index', 'cluster']]
    fig, axs = plt.subplots(len(columns))
    fig.set_figwidth(15)
    fig.set_figheight(9)
    for ic, column in enumerate(columns):
        x_data = [i for i in range(len(df))]
        y_data = [0 for _ in range(len(df))]
        colors = [0 for _ in range(len(df))]
        for i, row in enumerate(x_train_df[['data_index', column]].iterrows()):
            data_index = row[1]['data_index']
            data_value = row[1][column]
            real_cluster = y_train_df[y_train_df.index==row[0]].values[0]
            pred_cluster = train_preds[i]
            y_data[int(data_index)] = data_value
            colors[int(data_index)] = 0 if (real_cluster == pred_cluster) else 1

        for i, row in enumerate(x_test_df[['data_index', column]].iterrows()):
            data_index = row[1]['data_index']
            data_value = row[1][column]
            real_cluster = y_test_df[y_test_df.index==row[0]].values[0]
            pred_cluster = test_preds[i]
            y_data[int(data_index)] = data_value
            colors[int(data_index)] = 0 if (real_cluster == pred_cluster) else 1

        if (len(columns) > 1):
            axs[ic].set_title(column)
            axs[ic].set_ylim(max(df[columns].max()), min(df[columns].min()))
            axs[ic].scatter(x_data, y_data, c=colors)
        else:
            axs.set_title(column)
            axs.set_ylim(max(df[columns].max()), min(df[columns].min()))
            axs.scatter(x_data, y_data, c=colors)
    fig.savefig(os.path.join("classificação/", "kmeans/", f"{csv.strip('.csv')}.png"))

csvs = [fn for fn in os.listdir(dbscan_dir) if fn.endswith(".csv")]

for csv in csvs:
    df = pandas.read_csv(os.path.join(dbscan_dir, csv))
    x_df = df.drop("cluster", axis=1)
    y_df = df["cluster"]
    x_train_df, x_test_df, y_train_df, y_test_df = train_test_split(x_df, y_df, test_size=0.3)
    knn_model = KNeighborsRegressor(n_neighbors=3)
    knn_model.fit(x_train_df, y_train_df)
    train_preds = knn_model.predict(x_train_df)
    mse = mean_squared_error(y_train_df.values, train_preds)
    rmse = math.sqrt(mse)
    print(f"[DBScan {csv}] Erro medio quadratico treino: {rmse}")
    test_preds = knn_model.predict(x_test_df)
    mse = mean_squared_error(y_test_df, test_preds)
    rmse = math.sqrt(mse)
    print(f"[DBScan {csv}] Erro medio quadratico teste: {rmse}")

    columns = [c for c in df.columns if c not in ['Unnamed: 0', 'data_index', 'cluster']]
    fig, axs = plt.subplots(len(columns))
    fig.set_figwidth(15)
    fig.set_figheight(9)
    for ic, column in enumerate(columns):
        x_data = [i for i in range(len(df))]
        y_data = [0 for _ in range(len(df))]
        colors = [0 for _ in range(len(df))]
        for i, row in enumerate(x_train_df[['data_index', column]].iterrows()):
            data_index = row[1]['data_index']
            data_value = row[1][column]
            real_cluster = y_train_df[y_train_df.index==row[0]].values[0]
            pred_cluster = train_preds[i]
            y_data[int(data_index)] = data_value
            colors[int(data_index)] = 0 if (real_cluster == pred_cluster) else 1

        for i, row in enumerate(x_test_df[['data_index', column]].iterrows()):
            data_index = row[1]['data_index']
            data_value = row[1][column]
            real_cluster = y_test_df[y_test_df.index==row[0]].values[0]
            pred_cluster = test_preds[i]
            y_data[int(data_index)] = data_value
            colors[int(data_index)] = 0 if (real_cluster == pred_cluster) else 1

        if (len(columns) > 1):
            axs[ic].set_title(column)
            axs[ic].set_ylim(max(df[columns].max()), min(df[columns].min()))
            axs[ic].scatter(x_data, y_data, c=colors)
        else:
            axs.set_title(column)
            axs.set_ylim(max(df[columns].max()), min(df[columns].min()))
            axs.scatter(x_data, y_data, c=colors)
    fig.savefig(os.path.join("classificação/", "dbscan/", f"{csv.strip('.csv')}.png"))