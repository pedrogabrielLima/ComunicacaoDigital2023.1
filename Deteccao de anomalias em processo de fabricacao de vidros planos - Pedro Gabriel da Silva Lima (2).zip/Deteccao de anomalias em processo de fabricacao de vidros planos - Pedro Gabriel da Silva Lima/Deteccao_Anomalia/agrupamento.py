import os
import pandas
import ckwrap
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from kneed import KneeLocator

agrupamento_dir = "agrupamento"
os.makedirs(agrupamento_dir, exist_ok=True)
dbscan_dir = os.path.join(agrupamento_dir, "dbscan")
os.makedirs(dbscan_dir, exist_ok=True)
kmeans_dir = os.path.join(agrupamento_dir, "kmeans")
os.makedirs(kmeans_dir, exist_ok=True)

def optimal_groups_elbow(valores, mono=False):
    inertias = []
    K = range(1, 10)

    if (mono):
        values = valores.values.reshape(-1, 1)
    else:
        values = valores.values

    for k in K:
        kmeanModel = KMeans(n_clusters=k, n_init="auto").fit(values)
        inertias.append(kmeanModel.inertia_)
    
    kneedle = KneeLocator(K, inertias, S=2, curve="convex", direction="decreasing", online=True)
    return kneedle.elbow
    
def one_dimensional_cluster(points, eps):
    clusters = []
    points = [{"index": i, "value": point} for i, point in enumerate(points)]
    points_sorted = sorted(points, key=lambda d: d["value"])
    curr_point = points_sorted[0]
    curr_cluster = [curr_point]
    for point in points_sorted[1:]:
        if point["value"] <= curr_point["value"] + eps:
            curr_cluster.append(point)
        else:
            clusters.append(curr_cluster)
            curr_cluster = [point]
        curr_point = point
    clusters.append(curr_cluster)
    return clusters

def dbscan_1d(valores, eps, nome):
    clusters = one_dimensional_cluster(valores, eps)
    cluster_df = pandas.DataFrame(data=[[p['index'], p['value'], i+1] for i, c in enumerate(clusters) for p in c], columns=["data_index", "value", "cluster"])
    destino_csv = os.path.join(agrupamento_dir, "dbscan", f"{nome}.csv")
    cluster_df.to_csv(destino_csv)
    destino_png = os.path.join(agrupamento_dir, "dbscan", f"{nome}.png")
    fig, ax = plt.subplots(1)
    fig.set_figwidth(15)
    fig.set_figheight(9)
    ax.set_title(nome)
    ax.scatter(cluster_df.data_index, cluster_df.value, c=cluster_df.cluster)
    fig.savefig(destino_png)

def kmeans_1d(valores, nome):
    n_clusters = int(optimal_groups_elbow(valores, mono=True))
    km = ckwrap.ckmeans(valores, n_clusters)
    cluster_df = pandas.DataFrame(data=sorted([[i, point, km.labels[i]+1] for i, point in enumerate(valores)], key=lambda p: p[-1]), columns=["data_index", "value", "cluster"])
    destino_csv = os.path.join(agrupamento_dir, "kmeans", f"{nome}.csv")
    cluster_df.to_csv(destino_csv)
    destino_png = os.path.join(agrupamento_dir, "kmeans", f"{nome}.png")
    fig, ax = plt.subplots(1)
    fig.set_figwidth(15)
    fig.set_figheight(9)
    ax.set_title(nome)
    ax.scatter(cluster_df.data_index, cluster_df.value, c=cluster_df.cluster)
    fig.savefig(destino_png)

def dbscan(valores, eps, nome):
    clusters = DBSCAN(eps=eps, min_samples=1).fit(valores.values)
    max_v = min_v = valores.values[0][0]
    data = []
    for i, row in enumerate(valores.values):
        data_row = [i]
        for n in range(len(row)):
            data_row.append(row[n])
            if (row[n] > max_v):
                max_v = row[n]
            if (row[n] < min_v):
                min_v = row[n]
        data_row.append(clusters.labels_[i]+1)
        data.append(data_row)
    columns = ["data_index"]
    for column in valores.columns:
        columns.append(f"{column} value")
    columns.append("cluster")
    cluster_df = pandas.DataFrame(data=sorted(data, key=lambda p: p[-1]), columns=columns)
    destino_csv = os.path.join(agrupamento_dir, "dbscan", f"{nome}.csv")
    cluster_df.to_csv(destino_csv)
    destino_png = os.path.join(agrupamento_dir, "dbscan", f"{nome}.png")
    fig, axs = plt.subplots(len(valores.columns))
    fig.set_figwidth(15)
    fig.set_figheight(9)
    for i, column in enumerate(valores.columns):
        axs[i].set_title(column)
        axs[i].set_ylim(min_v, max_v)
        axs[i].scatter(cluster_df.data_index, cluster_df[f"{column} value"], c=cluster_df.cluster)
    fig.savefig(destino_png)

def kmeans(valores, nome):
    pca = PCA(n_components=2).fit(valores)
    pca_valores = pca.transform(valores)
    n_clusters = optimal_groups_elbow(valores)
    clusters = KMeans(n_clusters=n_clusters, init="k-means++", n_init="auto").fit(pca_valores)
    max_v = min_v = valores.values[0][0]
    data = []
    for i, row in enumerate(valores.values):
        data_row = [i]
        for n in range(len(row)):
            data_row.append(row[n])
            if (row[n] > max_v):
                max_v = row[n]
            if (row[n] < min_v):
                min_v = row[n]    
        data_row.append(clusters.labels_[i]+1)
        data.append(data_row)
    columns = ["data_index"]
    for column in valores.columns:
        columns.append(f"{column} value")
    columns.append("cluster")
    cluster_df = pandas.DataFrame(data=sorted(data, key=lambda p: p[-1]), columns=columns)
    destino_csv = os.path.join(agrupamento_dir, "kmeans", f"{nome}.csv")
    cluster_df.to_csv(destino_csv)
    destino_png = os.path.join(agrupamento_dir, "kmeans", f"{nome}.png")
    fig, axs = plt.subplots(len(valores.columns))
    fig.set_figwidth(15)
    fig.set_figheight(9)
    for i, column in enumerate(valores.columns):
        axs[i].set_title(column)
        axs[i].set_ylim(min_v, max_v)
        axs[i].scatter(cluster_df.data_index, cluster_df[f"{column} value"], c=cluster_df.cluster)
    fig.savefig(destino_png)

df = pandas.read_csv("Time_Series_Tratado.csv")

params = df.Parâmetro.unique()
params.sort()
grouped_df = df.groupby("Parâmetro")

eps = 0.05
for param in params:
    group = grouped_df.get_group(param)
    valores = group["Valor"]
    dbscan_1d(valores, eps, param)
    kmeans_1d(valores, param)


pivoted_df = pandas.DataFrame(data=[list(l) for l in zip(*df.groupby("Parâmetro")["Valor"].apply(list).values)], columns=params)
groups = {"ppm banhos": ["ppm O2 banho 1", "ppm O2 banho 2", "ppm O2 banho 3"], "ppm banhos + White Martins": ["ppm O2 banho 1", "ppm O2 banho 2", "ppm O2 banho 3", "ppm O2 White Martins"], "Condutividade - pH": ["Condutividade água aplicação líquida", "pH água aplicação líquida"]}
for name, group in groups.items():
    valores = pivoted_df[group]
    dbscan(valores, eps, name)
    kmeans(valores, name)