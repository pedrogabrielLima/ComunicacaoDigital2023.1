import os
import math
import pandas
import missingno
import statistics
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta

def normalizar(n, max, min):
    return (2*((n - min) / (max - min)))-1

if (not os.path.exists("figures")):
    os.mkdir("figures")


# Criando uma linha temporal de hora em hora 15/06/2022 ATE 01/09/2022
start_time = datetime(year=2022, month=6, day=15)
end_time = datetime(year=2022, month=9, day=1)
normalized_timestamps = []
while (start_time < end_time):
    normalized_timestamps.append(start_time)
    start_time = start_time + timedelta(hours=1)


# Definindo as colunas do final_df
final_df = pandas.DataFrame([], columns=["Parâmetro", "Valor", "Maximo", "Minimo", "InspectionDateHour"])

# Lendo o arquivo CSV e criando dataframe para o 'df'
df = pandas.read_csv("Time_Series_20_Persist_202209180830.csv")
# Definindo somente as variaveis principais do form "Online Params"
df = df[(df.Form == "Online Params") & (df.Grupo == "CEPVIX FLOAT - Top variáveis online")]
# Excluindo as colunas 'grupo, range, form, maximo e minimo'
df.drop("Grupo", inplace=True, axis=1)
df.drop("Form", inplace=True, axis=1)
df.drop("Range", inplace=True, axis=1)


# Definindo a margem de tempo de 2022-06-15 ate 2022-09-01
df = df.sort_values(by=["InspectionDateHour"])
df = df[(df.InspectionDateHour >= "2022-06-15") & (df.InspectionDateHour <= "2022-9-01" )]

# Removendo os parametros Espessura VMA esquerda e Espessura VMA direita
df = df[(df.Parâmetro != "Espessura VMA esquerda") & (df.Parâmetro != "Espessura VMA direita" )]

# Atribuindo a DF 'Parâmetros', os valores dos nomes das variaveis
params = df.Parâmetro.unique()
params.sort()

grouped_df = df.groupby("Parâmetro")

missing_data = [[] for _ in normalized_timestamps]

for i, param in enumerate(params):
   
    print(f"\n\n-------------------------\nWorking with param id {param}\n-------------------------\n")
    group = grouped_df.get_group(param)

    # Verificando se o grupo tem dados dentro do tempo especicado
    print("\nGroup size:", group.size)
    if (group.size == 0):
        print(f"Param {param} has no values between the specified times.. skipping")
        continue

    # se o numero maximo ou minimo do grupo for NAN, 
    # o numero maximo recebe a media dos valores + 3*stdev e o minimo a media dos valores - 3*stdev
    print("Getting maximum and minimum values")
    media_grupo = group.Valor.mean()
    
    max_value = group.Maximo.iloc[0]
    if math.isnan(max_value):
        max_value = media_grupo + 3 * statistics.stdev(group.Valor)
        
    min_value = group.Minimo.iloc[0]
    if math.isnan(min_value):
        min_value = media_grupo - 3 * statistics.stdev(group.Valor)

    print("Generating normalized values for our timestamps")
    values = []
    for n, timestamp in enumerate(normalized_timestamps):
        value = group.loc[group['InspectionDateHour'] == timestamp.strftime("%Y-%m-%d %H:%M:%S.000")].Valor
        # Se nao tiver dados naquela determinada faixa de tempo, o valor assumido é a media da variavel
        if (value.size == 0):
            missing_data[n].append(np.nan)
            value = values[-1] if len(values) else media_grupo
        else:
            missing_data[n].append(1)
            value = value.iloc[0]
        values.append(value)
    
    # Pegando o desvio padrão do grupo baseado apenas nas variaveis dentro do processo padrão
    std_values = []
    for value in values:
        if value < max_value and value > min_value:
            std_values.append(value)    
    stdev_grupo = statistics.stdev(std_values)

    # Definindo a media, os limites superior e inferior baseados nas minhas variaveis padrões
    media_grupo = sum(std_values)/len(std_values)
    limite_superior = media_grupo + 3 * stdev_grupo
    limite_inferior = media_grupo - 3 * stdev_grupo
    
    print("Appending data to our final dataframe")
    data = [[param, normalizar(values[i], group.Valor.max(), group.Valor.min()), limite_superior, limite_inferior, normalized_timestamps[i]] for i in range(len(values))]
    final_df = pandas.concat([final_df, pandas.DataFrame(data, columns=["Parâmetro", "Valor", "Maximo", "Minimo", "InspectionDateHour"])])
    
    print("Creating graph")
    plt.figure(i)
    fig, axs = plt.subplots(2)
    fig.set_figwidth(15)
    fig.set_figheight(12)
    axs[0].axhline(y=limite_superior, color='r')
    axs[0].axhline(y=limite_inferior, color='g')
    axs[0].axhline(y=media_grupo, color='k')
    axs[0].plot(normalized_timestamps, values, color='b')
    axs[0].set_xlim(normalized_timestamps[0], normalized_timestamps[-1])
    axs[1].plot(normalized_timestamps, [v[1] for v in data], color='b')
    axs[1].set_xlim(normalized_timestamps[0], normalized_timestamps[-1])
    fig.savefig(os.path.join("figures", f"{param}.png"))

missingno.matrix(pandas.DataFrame(missing_data, columns=params), figsize=(15,15), fontsize=8, sparkline=False)
plt.savefig("dados ausentes.png")

final_df.to_csv("Time_Series_Tratado.csv")