import pandas
import seaborn as sn
import matplotlib.pyplot as plt
from datetime import datetime

df = pandas.read_csv("Time_Series_Tratado.csv")

plt.figure(figsize=(20, 6))
sn.boxplot(x = 'Parâmetro', y = 'Valor', data = df, showfliers=False)
plt.savefig("box.png")

params = df.Parâmetro.unique()
params.sort()

ts = [datetime.strptime(v, "%Y-%m-%d %H:%M:%S") for v in df[(df.Parâmetro == params[0])].InspectionDateHour.values]

df = pandas.DataFrame(data=[list(l) for l in zip(*df.groupby("Parâmetro")["Valor"].apply(list).values)], columns=params)
correlation = df.corr()
fig, ax = plt.subplots(figsize=(25,25))
plot = sn.heatmap(correlation, annot = True, fmt=".1f", linewidths=.6, ax=ax) 
fig = plot.get_figure()
fig.savefig("tabela_correlacao.png")

groups = {"ppm banhos": ["ppm O2 banho 1", "ppm O2 banho 2", "ppm O2 banho 3"], "ppm banhos + White Martins": ["ppm O2 banho 1", "ppm O2 banho 2", "ppm O2 banho 3", "ppm O2 White Martins"], "Condutividade - pH": ["Condutividade água aplicação líquida", "pH água aplicação líquida"]}
for name, group in groups.items():
    plt.figure(figsize=(15, 6))
    for param in df:
        if (param in group):
           plt.plot(ts, df[param].values, label=param)
    plt.legend()
    plt.savefig(f"{name}.png")

